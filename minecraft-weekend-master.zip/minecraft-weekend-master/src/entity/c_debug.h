#ifndef C_DEBUG_H
#define C_DEBUG_H

#include "../util/util.h"

struct DebugComponent {
    bool enabled;
};

#endif