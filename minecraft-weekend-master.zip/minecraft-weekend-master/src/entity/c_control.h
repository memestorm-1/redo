#ifndef C_CONTROL_H
#define C_CONTROL_H

#include "../util/util.h"

struct ControlComponent {
    f32 mouse_sensitivity;
};

#endif